﻿namespace Dorm_and_Meal_Plan_Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.allenhallRadiobutton = new System.Windows.Forms.RadioButton();
            this.pikehallRadiobutton = new System.Windows.Forms.RadioButton();
            this.farthinghallRadiobutton = new System.Windows.Forms.RadioButton();
            this.suitesRadiobutton = new System.Windows.Forms.RadioButton();
            this.sevenmealsRadiobutton = new System.Windows.Forms.RadioButton();
            this.fourteenmealsRadiobutton = new System.Windows.Forms.RadioButton();
            this.unlimitedmealsRadiobutton = new System.Windows.Forms.RadioButton();
            this.calcbutton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.suitesRadiobutton);
            this.groupBox1.Controls.Add(this.farthinghallRadiobutton);
            this.groupBox1.Controls.Add(this.pikehallRadiobutton);
            this.groupBox1.Controls.Add(this.allenhallRadiobutton);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 116);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Dorms";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.unlimitedmealsRadiobutton);
            this.groupBox2.Controls.Add(this.fourteenmealsRadiobutton);
            this.groupBox2.Controls.Add(this.sevenmealsRadiobutton);
            this.groupBox2.Location = new System.Drawing.Point(13, 135);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 100);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Meal Plans";
            // 
            // allenhallRadiobutton
            // 
            this.allenhallRadiobutton.AutoSize = true;
            this.allenhallRadiobutton.Location = new System.Drawing.Point(7, 20);
            this.allenhallRadiobutton.Name = "allenhallRadiobutton";
            this.allenhallRadiobutton.Size = new System.Drawing.Size(108, 17);
            this.allenhallRadiobutton.TabIndex = 0;
            this.allenhallRadiobutton.TabStop = true;
            this.allenhallRadiobutton.Text = "Allen Hall ($1500)";
            this.allenhallRadiobutton.UseVisualStyleBackColor = true;
            // 
            // pikehallRadiobutton
            // 
            this.pikehallRadiobutton.AutoSize = true;
            this.pikehallRadiobutton.Location = new System.Drawing.Point(7, 44);
            this.pikehallRadiobutton.Name = "pikehallRadiobutton";
            this.pikehallRadiobutton.Size = new System.Drawing.Size(106, 17);
            this.pikehallRadiobutton.TabIndex = 1;
            this.pikehallRadiobutton.TabStop = true;
            this.pikehallRadiobutton.Text = "Pike Hall ($1600)";
            this.pikehallRadiobutton.UseVisualStyleBackColor = true;
            // 
            // farthinghallRadiobutton
            // 
            this.farthinghallRadiobutton.AutoSize = true;
            this.farthinghallRadiobutton.Location = new System.Drawing.Point(7, 68);
            this.farthinghallRadiobutton.Name = "farthinghallRadiobutton";
            this.farthinghallRadiobutton.Size = new System.Drawing.Size(123, 17);
            this.farthinghallRadiobutton.TabIndex = 2;
            this.farthinghallRadiobutton.TabStop = true;
            this.farthinghallRadiobutton.Text = "Farthing Hall ($1800)";
            this.farthinghallRadiobutton.UseVisualStyleBackColor = true;
            // 
            // suitesRadiobutton
            // 
            this.suitesRadiobutton.AutoSize = true;
            this.suitesRadiobutton.Location = new System.Drawing.Point(7, 92);
            this.suitesRadiobutton.Name = "suitesRadiobutton";
            this.suitesRadiobutton.Size = new System.Drawing.Size(142, 17);
            this.suitesRadiobutton.TabIndex = 3;
            this.suitesRadiobutton.TabStop = true;
            this.suitesRadiobutton.Text = "University Suites ($2500)";
            this.suitesRadiobutton.UseVisualStyleBackColor = true;
            // 
            // sevenmealsRadiobutton
            // 
            this.sevenmealsRadiobutton.AutoSize = true;
            this.sevenmealsRadiobutton.Location = new System.Drawing.Point(7, 20);
            this.sevenmealsRadiobutton.Name = "sevenmealsRadiobutton";
            this.sevenmealsRadiobutton.Size = new System.Drawing.Size(146, 17);
            this.sevenmealsRadiobutton.TabIndex = 0;
            this.sevenmealsRadiobutton.TabStop = true;
            this.sevenmealsRadiobutton.Text = "7 Meals Per Week ($600)";
            this.sevenmealsRadiobutton.UseVisualStyleBackColor = true;
            // 
            // fourteenmealsRadiobutton
            // 
            this.fourteenmealsRadiobutton.AutoSize = true;
            this.fourteenmealsRadiobutton.Location = new System.Drawing.Point(7, 44);
            this.fourteenmealsRadiobutton.Name = "fourteenmealsRadiobutton";
            this.fourteenmealsRadiobutton.Size = new System.Drawing.Size(158, 17);
            this.fourteenmealsRadiobutton.TabIndex = 1;
            this.fourteenmealsRadiobutton.TabStop = true;
            this.fourteenmealsRadiobutton.Text = "14 Meals Per Week ($1200)";
            this.fourteenmealsRadiobutton.UseVisualStyleBackColor = true;
            // 
            // unlimitedmealsRadiobutton
            // 
            this.unlimitedmealsRadiobutton.AutoSize = true;
            this.unlimitedmealsRadiobutton.Location = new System.Drawing.Point(7, 68);
            this.unlimitedmealsRadiobutton.Name = "unlimitedmealsRadiobutton";
            this.unlimitedmealsRadiobutton.Size = new System.Drawing.Size(138, 17);
            this.unlimitedmealsRadiobutton.TabIndex = 2;
            this.unlimitedmealsRadiobutton.TabStop = true;
            this.unlimitedmealsRadiobutton.Text = "Unlimited Meals ($1700)";
            this.unlimitedmealsRadiobutton.UseVisualStyleBackColor = true;
            // 
            // calcbutton
            // 
            this.calcbutton.Location = new System.Drawing.Point(219, 12);
            this.calcbutton.Name = "calcbutton";
            this.calcbutton.Size = new System.Drawing.Size(75, 23);
            this.calcbutton.TabIndex = 2;
            this.calcbutton.Text = "Calculate";
            this.calcbutton.UseVisualStyleBackColor = true;
            this.calcbutton.Click += new System.EventHandler(this.calcbutton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(219, 42);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 3;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(219, 72);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 238);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "***All Prices Per Semester";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(301, 264);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calcbutton);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Dorm and Meal Plan Calculator";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton suitesRadiobutton;
        private System.Windows.Forms.RadioButton farthinghallRadiobutton;
        private System.Windows.Forms.RadioButton pikehallRadiobutton;
        private System.Windows.Forms.RadioButton allenhallRadiobutton;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton unlimitedmealsRadiobutton;
        private System.Windows.Forms.RadioButton fourteenmealsRadiobutton;
        private System.Windows.Forms.RadioButton sevenmealsRadiobutton;
        private System.Windows.Forms.Button calcbutton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label label1;
    }
}

