﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//jake gudenkauf
namespace Dorm_and_Meal_Plan_Calculator
{
    public partial class Total_Charges : Form
    {
        public Total_Charges()
        {
            InitializeComponent();
        }

        private void outputLabel_Click(object sender, EventArgs e)
        {
            //oops
        }

        private void closeButton_Click(object sender, EventArgs e)
        {
            //closes form
            this.Close();
        }
    }
}
